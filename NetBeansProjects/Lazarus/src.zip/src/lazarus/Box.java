package lazarus;

import java.awt.Image;
import java.awt.Point;
import wingman.game.Ship;

public class Box extends Ship{
    public Box(Point position, Point speed, int damage, Image img){
        super(position, speed, damage, img);
    }

    public void setSpeed(Point boxLocation){
        speed = boxLocation;
    }

    public int getStrength(){
        return strength;
    }
    @Override
    public void fire(){
    }
}
