package lazarus;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import wingman.GameClock;
import wingman.GameSounds;
import wingman.GameWorld;
import wingman.game.BackgroundObject;
import wingman.game.Bullet;
import wingman.game.PlayerShip;
import wingman.modifiers.AbstractGameModifier;

public class LazarusWorld
        extends GameWorld {

    private Thread thread;
    public ArrayList<Box> boxArray;
    public ArrayList<Box> wallArray;
    public ArrayList<Box> boxesFalling;
    public ArrayList<StopButton> stopButtons;
    private ArrayList<ArrayList<Box>> fallenBoxes;
    static boolean gameOver;
    static boolean winner;
    boolean gameEnded;
    ImageObserver observer;
    SoundPlayer sp;
    Graphics2D g2;
    private static final LazarusWorld myGame = new LazarusWorld();
    public static final GameClock clock = new GameClock();
    public LazarusLevel level;
    public static HashMap<String, Image> sprites = GameWorld.sprites;
    private BufferedImage bimg;
    int sizeX;
    int sizeY;
    static int first = 0;
    Point mapSize;
    public ArrayList<PlayerShip> players;

    private LazarusWorld() {
        setFocusable(true);
        this.boxesFalling = new ArrayList<Box>();
        this.fallenBoxes = new ArrayList<ArrayList<Box>>(16);
        this.stopButtons = new ArrayList<StopButton>();
        for (int i = 16; i > 0; i--)
            this.fallenBoxes.add(new ArrayList<Box>());
        this.background = new ArrayList<BackgroundObject>();
        this.players = new ArrayList<PlayerShip>();
        this.boxArray = new ArrayList<Box>();
        this.wallArray = new ArrayList<Box>();

    }

    public static void main(String[] argv) {
        LazarusWorld game = getLazarus();
        JFrame f = new JFrame("Lazarus Game");
        f.getContentPane().add("Center", game);
        f.pack();
        f.setSize(new Dimension(640, 505));
        game.setNewDimensions(640, 480);
        game.init();
        f.setVisible(true);
        f.setResizable(false);
        f.setDefaultCloseOperation(3);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        game.start();
    }

    public void init() {
        setBackground(Color.white);
        loadSprites();
        GameWorld.setSpeed(new Point(0, 0));
        this.level = new LazarusLevel("Resources/level.txt");
        clock.addObserver(this.level);
        this.level.addObserver(this);
        this.gameOver = false;
        this.observer = this;
        this.mapSize = new Point(this.level.w * 40, this.level.h * 40);

        LazarusWorld.this.addBckgrd(new BackgroundObject[]{new LazarusBackground(this.mapSize.x, this.mapSize.y, GameWorld.getSpeed(), (Image) sprites.get("background"))});
        sp = new SoundPlayer(1, "Resources/Music.wav");
//        this.menu = new GameMenu();
        this.level.load();
    }

    public void drawFrame(int w, int h, Graphics2D g2) {
        ListIterator<?> iterator = getObjs();
        while (iterator.hasNext()) {
            BackgroundObject obj = (BackgroundObject) iterator.next();
            obj.update(w, h);
            obj.draw(g2, this);

            ListIterator<Box> fallingBoxes = getBoxesComingDown();
            while (fallingBoxes.hasNext()) {
                Box fallingBox = (Box) fallingBoxes.next();
                Rectangle fallingBoxX = fallingBox.getLocation();
                int fallingY = fallingBoxX.x / 40;

                ListIterator<PlayerShip> players = getPlayer();
                while (players.hasNext()) {
                    Lazarus currentPlayer = (Lazarus) players.next();
                    if (fallingBox.collision(currentPlayer)) {
                        currentPlayer.die();
                    }
                }
                ListIterator<Box> theBox = findBoxAtY(fallingY);
                boolean falling = false;
                while (theBox.hasNext()) {
                    Box groundBox = (Box) theBox.next();
                    if (fallingBox.collision(groundBox)) {
                        if (groundBox.getStrength() < fallingBox.getStrength()) {
                            groundBox.hide();
                            theBox.remove();
                            GameSounds.play("Resources/Crush.wav");
                        } else {
                            theBox.add(fallingBox);
                            fallingBoxes.remove();
                            falling = true;
                        }
                    }
                    groundBox.draw(g2, this);
                }
                if ((!falling) && (fallingBox.getY() > 360)) {
                    addFallenBox(fallingY, new Box[]{fallingBox});
                    fallingBoxes.remove();
                }
            }
        }
        if (!this.gameEnded) {
            iterator = getPlayer();
            while (iterator.hasNext()) {
                PlayerShip player = (PlayerShip) iterator.next();
                if (!player.isDead()) {
                    
                    // get wallboxes
                    ListIterator<Box> listOWallBoxes = this.wallArray.listIterator();
                    while (listOWallBoxes.hasNext()) {
                        Box nWall = listOWallBoxes.next();
                        nWall.draw(g2, this);
                    }
                    
                    // get stopbuttoms
                    ListIterator<StopButton> stopButtons = this.stopButtons.listIterator();
                    while (stopButtons.hasNext()) {
                        StopButton nWall = stopButtons.next();
                        nWall.draw(g2, this);
                    }
                    
                    // get next boxes
                    ListIterator<Box> listONewBoxes = this.boxArray.listIterator();
                    while (listONewBoxes.hasNext()) {
                        Box newBox = listONewBoxes.next();
                        newBox.draw(g2, this);
                    }
                    
                    // get boxes coming down 
                    ListIterator<Box> listOBoxesComingDown = this.boxesFalling.listIterator();
                    while (listOBoxesComingDown.hasNext()) {
                        Box newBox = listOBoxesComingDown.next();
                        newBox.update(w, h);
                        newBox.draw(g2, this);
                    }
                } else {
                    this.gameOver = true;
                    g2.setColor(Color.white);
                    g2.setFont(new Font("Calibri", 0, 26));
                    if (!this.winner) {
                        g2.drawString("\t\tGame Over!", this.sizeX / 4, 200);
                    } else {
                        g2.drawString("\t\tYou Win!", this.sizeX / 4, 200);
                    }
                }
            }
            PlayerShip p1 = (PlayerShip) this.players.get(0);
            p1.update(w, h);
            p1.draw(g2, this);
        }
    }

    public void start() {
        this.thread = new Thread(this);
        this.thread.setPriority(1);
        this.thread.start();
    }

    public static LazarusWorld getLazarus() {
        return myGame;
    }

    public ListIterator<BackgroundObject> getObjs() {
        return this.background.listIterator();
    }

    public ListIterator<Box> getBoxesComingDown() {
        return this.boxesFalling.listIterator();
    }

    public ListIterator<PlayerShip> getPlayer() {
        return this.players.listIterator();
    }

    public void setNewDimensions(int w, int h) {
        this.sizeX = w;
        this.sizeY = h;
    }

    public void addBckgrd(BackgroundObject... objects) {
        BackgroundObject[] arrayOfBackgroundObject;
        int j = (arrayOfBackgroundObject = objects).length;
        for (int i = 0; i < j; i++) {
            BackgroundObject object = arrayOfBackgroundObject[i];
            this.background.add(object);
            if ((object instanceof LazarusBackground)) {
            }
        }
    }

    public void addNewPlayer(PlayerShip... objects) {
        PlayerShip[] arrayOfPlayerShip;
        int j = (arrayOfPlayerShip = objects).length;
        for (int i = 0; i < j; i++) {
            PlayerShip player = arrayOfPlayerShip[i];
            this.players.add(player);
        }
    }

    public void addBckgrd(Box... aBox) {
        Box[] arrayOfBox;
        int j = (arrayOfBox = aBox).length;
        for (int i = 0; i < j; i++) {
            Box object = arrayOfBox[i];
            this.boxArray.add(object);
        }
    }

    public void addFallenBox(int y, Box... fallenBox) {
        Box[] arrayOfBox;
        int j = (arrayOfBox = fallenBox).length;
        for (int i = 0; i < j; i++) {
            Box object = arrayOfBox[i];
            this.fallenBoxes.get(y).add(object);
        }
    }

    public ListIterator<Box> findBoxAtY(int y) {
        return this.fallenBoxes.get(y).listIterator();
    }

    public int numberOfFallenBoxes(int y, int x) {
        int count = 0;
        ListIterator<Box> listOfBoxes = findBoxAtY(y);
        while (listOfBoxes.hasNext()) {
            Box newBox = (Box) listOfBoxes.next();
            if (newBox.getY() < x) {
                count++;
            }
        }
        return count;
    }

    public ListIterator<Box> getWallItems() {
        return this.wallArray.listIterator();
    }

    @Override
    public Graphics2D createGraphics2D(int w, int h) {
        Graphics2D g2 = null;
        if ((this.bimg == null) || (this.bimg.getWidth() != w) || (this.bimg.getHeight() != h)) {
            this.bimg = ((BufferedImage) createImage(w, h));
        }
        g2 = this.bimg.createGraphics();
        g2.setBackground(getBackground());
        g2.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        g2.clearRect(0, 0, w, h);
        return g2;
    }

    @Override
    public void paint(Graphics g) {
        clock.tick();
        g2 = createGraphics2D(getSize().width, getSize().height);
        drawFrame(getSize().width, getSize().height, g2);
        g2.dispose();
        g.drawImage(this.bimg, 0, 0, this);
    }

    @Override
    public void addClockObserver(Observer object) {
        clock.addObserver(object);
    }

    @Override
    protected void loadSprites() {
        sprites.put("Title", getSprite("Resources/Title.gif"));
        sprites.put("player1", getSprite("Resources/Lazarus_stand.gif"));
        sprites.put("background", getSprite("Resources/Background.bmp"));
        sprites.put("wall", getSprite("Resources/Wall.gif"));
        sprites.put("CardBox", getSprite("Resources/CardBox.gif"));
        sprites.put("WoodBox", getSprite("Resources/WoodBox.gif"));
        sprites.put("MetalBox", getSprite("Resources/MetalBox.gif"));
        sprites.put("Lazarus_jump_left", getSprite("Resources/Lazarus_jump_left.gif"));
        sprites.put("Lazarus_jump_right", getSprite("Resources/Lazarus_jump_right.gif"));
        sprites.put("Lazarus_left", getSprite("Resources/Lazarus_left.gif"));
        sprites.put("Lazarus_right", getSprite("Resources/Lazarus_right.gif"));
        sprites.put("Lazarus_squished", getSprite("Resources/Lazarus_squished.gif"));
        sprites.put("Lazarus_stand", getSprite("Resources/Lazarus_stand.gif"));
        sprites.put("StoneBox", getSprite("Resources/StoneBox.gif"));
        sprites.put("StopButton", getSprite("Resources/Button.gif"));
        sprites.put("Lazarus_afraid", getSprite("Resources/Lazarus_afraid.gif"));
    }

    @Override
    public Image getSprite(String name) {
        Image img = null;
        try {
            img = ImageIO.read(LazarusWorld.class.getResource(name));
        } catch (IOException ex) {
            Logger.getLogger(LazarusWorld.class.getName()).log(Level.SEVERE, null, ex);
        }
        return img;
    }

    @Override
    public void run() {
        Thread athread = Thread.currentThread();
        while (this.thread == athread) {
            requestFocusInWindow();
            repaint();
            try {
                Thread.sleep(8);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    @Override
    public void update(Observable object, Object arg) {
        AbstractGameModifier modifier = (AbstractGameModifier) object;
        modifier.read(this);
    }

    @Override
    public void addBullet(Bullet... newObjects) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
